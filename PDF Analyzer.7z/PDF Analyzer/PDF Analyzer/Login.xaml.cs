﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PDF_Analyzer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            this.Opacity = 0;
            InitializeComponent();
            //lbl_header_login.FontFamily = new FontFamily(new Uri("pack://application:,,,/"), "./Fonts/#QuickSand Bold");
        }

        private void Txt_pwd_login_MouseEnter(object sender, MouseEventArgs e)
        {
            ThicknessAnimation marginAnim = new ThicknessAnimation();
            marginAnim.From = new Thickness(70, 200, 0, 0);
            marginAnim.To = new Thickness(70, 185, 0, 0);
            marginAnim.Duration = TimeSpan.FromMilliseconds(250);
            lbl_pwd_login.BeginAnimation(Label.MarginProperty, marginAnim);
        }

        private void Txt_pwd_login_MouseLeave(object sender, MouseEventArgs e)
        {
            ThicknessAnimation marginAnim = new ThicknessAnimation();
            marginAnim.From = new Thickness(70, 185, 0, 0);
            marginAnim.To = new Thickness(70, 200, 0, 0);
            marginAnim.Duration = TimeSpan.FromMilliseconds(250);
            lbl_pwd_login.BeginAnimation(Label.MarginProperty, marginAnim);
        }

        private void Txt_usr_login_MouseEnter(object sender, MouseEventArgs e)
        {
            ThicknessAnimation marginAnim = new ThicknessAnimation();
            marginAnim.From = new Thickness(70, 130, 0, 0);
            marginAnim.To = new Thickness(70, 115, 0, 0);
            marginAnim.Duration = TimeSpan.FromMilliseconds(250);
            lbl_user_login.BeginAnimation(Label.MarginProperty, marginAnim);
        }

        private void Txt_usr_login_MouseLeave(object sender, MouseEventArgs e)
        {
            ThicknessAnimation marginAnim = new ThicknessAnimation();
            marginAnim.From = new Thickness(70, 115, 0, 0);
            marginAnim.To = new Thickness(70, 130, 0, 0);
            marginAnim.Duration = TimeSpan.FromMilliseconds(250);
            lbl_user_login.BeginAnimation(Label.MarginProperty, marginAnim);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DoubleAnimation fader = new DoubleAnimation(0, TimeSpan.FromMilliseconds(200));
            lbl_header_login.BeginAnimation(OpacityProperty, fader);
            lbl_user_login.BeginAnimation(OpacityProperty, fader);
            lbl_pwd_login.BeginAnimation(OpacityProperty, fader);
            txt_usr_login.BeginAnimation(OpacityProperty, fader);
            txt_pwd_login.BeginAnimation(OpacityProperty, fader);
            btn_connect.BeginAnimation(OpacityProperty, fader);
            ThicknessAnimation mover = new ThicknessAnimation();
            mover.From = new Thickness(410, 10, 0, 0);
            mover.To = new Thickness(10, 10, 0, 0);
            mover.BeginTime = TimeSpan.FromMilliseconds(350);
            mover.Duration = TimeSpan.FromMilliseconds(800);
            img_login_logo.BeginAnimation(MarginProperty, mover);
        }

        private void Window_login_Loaded(object sender, RoutedEventArgs e)
        {
            DoubleAnimation fader = new DoubleAnimation(1, TimeSpan.FromMilliseconds(500));
            this.BeginAnimation(Splash.OpacityProperty, fader);
        }
    }
}
