﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PDF_Analyzer
{
    /// <summary>
    /// Interaction logic for Splash.xaml
    /// </summary>
    public partial class Splash : Window
    {
        public Splash()
        {
            this.Opacity = 0;
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ThicknessAnimation mover = new ThicknessAnimation();
            mover.From = new Thickness(0, 0, 0, 0);
            mover.To = new Thickness(0, -400, 0, 0);
            //mover.BeginTime = TimeSpan.FromMilliseconds(350);
            mover.Duration = TimeSpan.FromMilliseconds(500);
            mover.Completed += new EventHandler(nextwindow);
            image.BeginAnimation(MarginProperty, mover);
        }

        private void nextwindow(object sender, EventArgs e)
        {
            DoubleAnimation fader = new DoubleAnimation(0, TimeSpan.FromMilliseconds(500));
            this.BeginAnimation(Splash.OpacityProperty, fader);
            MainWindow login = new MainWindow();
            login.Show();
            this.Hide();
            //this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DoubleAnimation fader = new DoubleAnimation(1, TimeSpan.FromMilliseconds(2500));
            this.BeginAnimation(Splash.OpacityProperty, fader);
        }
    }
}
